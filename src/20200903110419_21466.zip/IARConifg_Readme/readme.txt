使用说明：
把config文件夹下的最后一层的文件夹XMC复制到相应的Embedded Workbench 8.2\arm\config下对应的文件夹下。
例如config\debugger下的XMC文件夹，整个复制到Embedded Workbench 8.2\arm\config\debugger下，
这样就存在Embedded Workbench 8.2\arm\config\debugger\XMC这个文件夹。其他类似。

V1.0 
发布初版

V1.1
解决部分IAR项目工程出现FLASH下载界面卡住的情况